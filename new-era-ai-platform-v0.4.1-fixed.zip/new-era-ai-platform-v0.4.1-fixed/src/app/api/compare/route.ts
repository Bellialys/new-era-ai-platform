import { NextRequest, NextResponse } from "next/server";
import {
  MODE_SLUG_PROMPT_ARENA,
  MODEL_MAX_SELECT,
  MODEL_MIN_SELECT,
  PROMPT_MAX_LENGTH,
  PROMPT_MIN_LENGTH,
} from "@/lib/arena/constants";
import {
  ApiError,
  createErrorResponse,
  fetchMultipleResponses,
  getModelById,
  logApiRequest,
  validateModeSlug,
  validateModelAllowlist,
  validateModelIds,
  validatePrompt,
} from "@/lib/server";

interface CompareRequest {
  prompt?: unknown;
  modelIds?: unknown;
  modeSlug?: unknown;
}

interface CompareModelResponse {
  id: string;
  modelId: string;
  modelName: string;
  status: "success" | "error";
  answerText: string | null;
  latencyMs?: number;
  errorCode?: string;
  errorMessage?: string;
}

interface CompareSuccessResponse {
  status: "success" | "error";
  modeSlug: string;
  responses: CompareModelResponse[];
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function jsonError(error: unknown): NextResponse {
  const safeError = createErrorResponse(error);
  const statusCode = error instanceof ApiError ? error.statusCode : 500;
  return NextResponse.json(safeError, { status: statusCode });
}

export async function POST(
  request: NextRequest
): Promise<NextResponse> {
  const startTime = Date.now();

  try {
    let rawBody: unknown;

    try {
      rawBody = await request.json();
    } catch {
      const error = new ApiError(400, "INVALID_JSON", "Invalid JSON body");
      logApiRequest("POST", "/api/compare", error.statusCode, Date.now() - startTime);
      return jsonError(error);
    }

    if (!isObject(rawBody)) {
      const error = new ApiError(400, "INVALID_BODY", "Request body must be a JSON object");
      logApiRequest("POST", "/api/compare", error.statusCode, Date.now() - startTime);
      return jsonError(error);
    }

    const body = rawBody as CompareRequest;

    const modeValidation = validateModeSlug(
      body.modeSlug,
      MODE_SLUG_PROMPT_ARENA
    );

    if (!modeValidation.valid || !modeValidation.value) {
      const error = new ApiError(
        400,
        "INVALID_MODE_SLUG",
        modeValidation.error ?? "Invalid modeSlug"
      );
      logApiRequest("POST", "/api/compare", error.statusCode, Date.now() - startTime);
      return jsonError(error);
    }

    const promptValidation = validatePrompt(
      body.prompt,
      PROMPT_MIN_LENGTH,
      PROMPT_MAX_LENGTH
    );

    if (!promptValidation.valid || !promptValidation.value) {
      const error = new ApiError(
        400,
        "VALIDATION_ERROR",
        promptValidation.error ?? "Invalid prompt"
      );
      logApiRequest("POST", "/api/compare", error.statusCode, Date.now() - startTime);
      return jsonError(error);
    }

    const modelIdValidation = validateModelIds(
      body.modelIds,
      MODEL_MIN_SELECT,
      MODEL_MAX_SELECT
    );

    if (!modelIdValidation.valid || !modelIdValidation.value) {
      const error = new ApiError(
        400,
        "VALIDATION_ERROR",
        modelIdValidation.error ?? "Invalid model IDs"
      );
      logApiRequest("POST", "/api/compare", error.statusCode, Date.now() - startTime);
      return jsonError(error);
    }

    try {
      validateModelAllowlist(modelIdValidation.value);
    } catch (error) {
      logApiRequest("POST", "/api/compare", 403, Date.now() - startTime);
      return jsonError(error);
    }

    const modelResults = await fetchMultipleResponses(
      promptValidation.value,
      modelIdValidation.value
    );

    const responses = modelIdValidation.value.map((modelId, index) => {
      const result = modelResults[index];
      const model = getModelById(modelId);
      const modelName = model?.name ?? modelId;

      if (result.success) {
        return {
          id: crypto.randomUUID(),
          modelId,
          modelName,
          status: "success" as const,
          answerText: result.text,
          latencyMs: result.latencyMs,
        };
      }

      return {
        id: crypto.randomUUID(),
        modelId,
        modelName,
        status: "error" as const,
        answerText: null,
        errorCode: result.errorCode,
        errorMessage: result.errorMessage,
      };
    });

    const hasAnySuccess = responses.some((response) => response.status === "success");

    logApiRequest("POST", "/api/compare", 200, Date.now() - startTime);

    return NextResponse.json(
      {
        status: hasAnySuccess ? "success" : "error",
        modeSlug: modeValidation.value,
        responses,
      },
      { status: 200 }
    );
  } catch (error) {
    console.error("POST /api/compare error:", error);
    logApiRequest("POST", "/api/compare", 500, Date.now() - startTime);
    return jsonError(error);
  }
}
