"use client";

import { useEffect, useRef, useState } from "react";
import {
  MODE_SLUG_PROMPT_ARENA,
  MODEL_MAX_SELECT,
  MODEL_MIN_SELECT,
  PROMPT_MAX_LENGTH,
  PROMPT_MIN_LENGTH,
} from "@/lib/arena/constants";
import type {
  ArenaApiResponse,
  ArenaModel,
  ArenaResponseView,
} from "@/types/arena";
import { ArenaForm } from "./arena-form";
import { ArenaResults } from "./arena-results";

const MAX_MODELS_ERROR_MESSAGE = "В MVP можно выбрать максимум три модели.";

export function PromptArena() {
  const [availableModels, setAvailableModels] = useState<ArenaModel[]>([]);
  const [modelsLoading, setModelsLoading] = useState(true);
  const [modelsError, setModelsError] = useState<string | null>(null);

  const [prompt, setPrompt] = useState("");
  const [selectedModelIds, setSelectedModelIds] = useState<string[]>([]);
  const [responses, setResponses] = useState<ArenaResponseView[]>([]);
  const [winnerResponseId, setWinnerResponseId] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const requestIdRef = useRef(0);
  const abortControllerRef = useRef<AbortController | null>(null);

  useEffect(() => {
    const controller = new AbortController();

    async function loadModels() {
      try {
        const response = await fetch("/api/models", {
          signal: controller.signal,
        });

        if (!response.ok) {
          throw new Error("Failed to load models");
        }

        const data = (await response.json()) as {
          status: string;
          models: ArenaModel[];
        };

        setAvailableModels(data.models);

        if (data.models.length >= MODEL_MIN_SELECT) {
          setSelectedModelIds(
            data.models.slice(0, MODEL_MIN_SELECT).map((model) => model.id)
          );
        }
      } catch (error) {
        if (error instanceof Error && error.name === "AbortError") {
          return;
        }

        console.error("Error loading models:", error);
        setModelsError(
          "Не удалось загрузить список моделей. Обновите страницу."
        );
      } finally {
        if (!controller.signal.aborted) {
          setModelsLoading(false);
        }
      }
    }

    loadModels();

    return () => {
      controller.abort();
      abortControllerRef.current?.abort();
    };
  }, []);

  function buildResponseViews(apiResponses: ArenaApiResponse[]): ArenaResponseView[] {
    return apiResponses.map((response) => {
      const matchedModel = availableModels.find(
        (model) => model.id === response.modelId
      );

      return {
        ...response,
        modelRole: matchedModel?.role ?? "Unknown model role",
      };
    });
  }

  function clearStaleResults() {
    requestIdRef.current += 1;
    abortControllerRef.current?.abort();
    abortControllerRef.current = null;
    setResponses([]);
    setWinnerResponseId(null);
    setIsLoading(false);
  }

  function validateForm() {
    const cleanPrompt = prompt.trim();

    if (cleanPrompt.length < PROMPT_MIN_LENGTH) {
      return "Введите задачу минимум из 3 символов.";
    }

    if (cleanPrompt.length > PROMPT_MAX_LENGTH) {
      return `Введите задачу не длиннее ${PROMPT_MAX_LENGTH} символов.`;
    }

    if (selectedModelIds.length < MODEL_MIN_SELECT) {
      return "Для сравнения нужно выбрать минимум две модели.";
    }

    if (selectedModelIds.length > MODEL_MAX_SELECT) {
      return MAX_MODELS_ERROR_MESSAGE;
    }

    return null;
  }

  function handlePromptChange(value: string) {
    setPrompt(value);
    setErrorMessage(null);
    clearStaleResults();
  }

  function handleToggleModel(modelId: string) {
    setErrorMessage(null);

    setSelectedModelIds((currentIds) => {
      if (currentIds.includes(modelId)) {
        clearStaleResults();
        return currentIds.filter((id) => id !== modelId);
      }

      if (currentIds.length >= MODEL_MAX_SELECT) {
        setErrorMessage(MAX_MODELS_ERROR_MESSAGE);
        return currentIds;
      }

      clearStaleResults();
      return [...currentIds, modelId];
    });
  }

  function handleSubmit() {
    const validationError = validateForm();

    if (validationError) {
      setErrorMessage(validationError);
      return;
    }

    const requestId = requestIdRef.current + 1;
    const controller = new AbortController();

    requestIdRef.current = requestId;
    abortControllerRef.current?.abort();
    abortControllerRef.current = controller;

    setErrorMessage(null);
    setIsLoading(true);
    setResponses([]);
    setWinnerResponseId(null);

    (async () => {
      try {
        const response = await fetch("/api/compare", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            prompt: prompt.trim(),
            modelIds: selectedModelIds,
            modeSlug: MODE_SLUG_PROMPT_ARENA,
          }),
          signal: controller.signal,
        });

        if (requestIdRef.current !== requestId) {
          return;
        }

        if (!response.ok) {
          const errorData = (await response.json()) as {
            message?: string;
            errorCode?: string;
          };

          throw new Error(errorData.message || `API error: ${response.status}`);
        }

        const data = (await response.json()) as {
          status: string;
          responses: ArenaApiResponse[];
        };

        if (!Array.isArray(data.responses)) {
          throw new Error("Invalid API response format");
        }

        setResponses(buildResponseViews(data.responses));
      } catch (error) {
        if (requestIdRef.current !== requestId) {
          return;
        }

        if (error instanceof Error && error.name === "AbortError") {
          return;
        }

        console.error("Error fetching responses:", error);
        setErrorMessage(
          error instanceof Error
            ? error.message
            : "Не удалось получить ответы. Попробуйте ещё раз."
        );
      } finally {
        if (requestIdRef.current === requestId) {
          setIsLoading(false);
          abortControllerRef.current = null;
        }
      }
    })();
  }

  function handleReset() {
    requestIdRef.current += 1;
    abortControllerRef.current?.abort();
    abortControllerRef.current = null;
    setPrompt("");

    if (availableModels.length >= MODEL_MIN_SELECT) {
      setSelectedModelIds(
        availableModels.slice(0, MODEL_MIN_SELECT).map((model) => model.id)
      );
    } else {
      setSelectedModelIds([]);
    }

    setResponses([]);
    setWinnerResponseId(null);
    setErrorMessage(null);
    setIsLoading(false);
  }

  return (
    <section className="grid gap-6 lg:grid-cols-[0.9fr_1.1fr]">
      <ArenaForm
        prompt={prompt}
        maxPromptLength={PROMPT_MAX_LENGTH}
        selectedModelIds={selectedModelIds}
        models={availableModels}
        modelsLoading={modelsLoading}
        isLoading={isLoading}
        errorMessage={errorMessage || modelsError}
        onPromptChange={handlePromptChange}
        onToggleModel={handleToggleModel}
        onSubmit={handleSubmit}
        onReset={handleReset}
      />

      <ArenaResults
        responses={responses}
        isLoading={isLoading}
        loadingModelNames={availableModels
          .filter((model) => selectedModelIds.includes(model.id))
          .map((model) => model.name)}
        winnerResponseId={winnerResponseId}
        onSelectWinner={setWinnerResponseId}
      />
    </section>
  );
}
